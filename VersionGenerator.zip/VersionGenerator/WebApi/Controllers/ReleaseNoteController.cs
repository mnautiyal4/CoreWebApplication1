﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;
using WebApi.Data;
using WebApi.Model;


namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ReleaseNoteController : ControllerBase
    {
        private readonly ReleaseNoteRepository _repository;


        public ReleaseNoteController(ReleaseNoteRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]

        public async Task<ActionResult<List<ReleaseNote>>> GetAllReleaseNotesAsync()
        {
            var IsValidtoken = await ValidateToken();

            if (IsValidtoken)
            {
                var items = await _repository.GetAllReleaseNotesAsync();
                return Ok(items);
            }
            else
            {
                return Unauthorized();
            }
        }

        [Route("viewreleasenotes")]
        [HttpGet]
        public async Task<ActionResult<List<StoredProcInput>>> GetStoredProcInput()
        {
            var items = await _repository.GetResultByProcedureInputAsync();
            return Ok(items);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ReleaseNote>> GetReleaseNoteByIdAsync(int id)
        {
            var item = await _repository.GetReleaseNoteByIdAsync(id);
            if (item == null)
                return NotFound();

            return Ok(item);
        }

        [Route("add")]
        [HttpPost]
        public async Task<ActionResult> AddReleaseNoteAsync(ReleaseNoteDataTransferObject releaseNoteDataTransferObject)
        {
            var response = await _repository.AddReleaseNoteAsync(releaseNoteDataTransferObject);
            if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                return BadRequest(response);
            }
            else
            {
                return Ok(response);
            }
            //return CreatedAtAction(nameof(GetReleaseNoteByIdAsync), new { id = item.Id }, item);
            //return NoContent(); 

        }

        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateReleaseNoteAsync(ReleaseNote item)
        {
            //List<StoredProcResult> lstresult= GetResult().Result;
            await _repository.UpdateReleaseNoteAsync(item);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteReleaseNoteAsync(int id)
        {
            await _repository.DeleteReleaseNoteAsync(id);
            return NoContent();
        }

        [Route("viewreleasenotedetails/{reldate}/{appname}")]
        [HttpGet]
        public async Task<ActionResult<List<ReleaseNote>>> GetReleaseNoteDetailsAsync(string reldate, string appname)
        {
            var items = await _repository.GetReleaseNoteDetailsAsync(reldate, appname);
            if (items == null)
                return NotFound();

            return Ok(items);
        }

        [Route("checkversion/{AppName}/{Epic}/{Feature}/{UserStory}/{Bug}")]
        [HttpGet]
        public async Task<ActionResult<List<StoredProcResult>>> GetResultByProcedureAsync(string AppName, byte Epic, byte Feature, byte UserStory, byte Bug)
        {
            var IsValidtoken = await ValidateToken();

            if (IsValidtoken)
            {
                var items = await _repository.GetResultByProcedureAsync(AppName, Epic, Feature, UserStory, Bug);
                if (items == null)
                    return Unauthorized();
                return Ok(items);
            }
            else
            {
                return Unauthorized();
            }

        }


        [HttpGet("applicationlist")]
        public async Task<ActionResult<List<ReleaseNoteThreshold>>> GetApplicationListAsync()
        {
            var items = await _repository.GetApplicationListAsync();
            return Ok(items);
        }


        [HttpGet("appdetails/{id}")]
        public async Task<ActionResult<ReleaseNoteThreshold>> GetApplicationListByIdAsync(int id)
        {
            var item = await _repository.GetApplicationListByIdAsync(id);
            if (item == null)
                return NotFound();

            return Ok(item);
        }

        [HttpPut("appdetails/{id}")]
        public async Task<ActionResult> UpdateApplicationDetailAsync(ReleaseNoteThreshold item)
        {
            //List<StoredProcResult> lstresult= GetResult().Result;
            await _repository.UpdateApplicationDetailAsync(item);
            return NoContent();
        }

        [HttpGet("getlastrecordsbyappname/{appname}/{reldate}")]
        public async Task<ActionResult<List<ReleaseNote>>> GetLastReleaseNoteListAsync(string appname, string reldate)
        {
            var items = await _repository.GetLastReleaseNoteListAsync(appname, reldate);
            return Ok(items);
        }

        [Route("register")]
        [HttpPost]
        public async Task<ActionResult> AddReleaseNoteUserAsync(ReleaseNoteUserInfo userinfo)
        {
            var IsValidtoken = await ValidateToken();

            if (IsValidtoken)
            {

                var response = await _repository.AddReleaseNoteUserAsync(userinfo);
                if (response.StatusCode == System.Net.HttpStatusCode.Conflict)
                    return BadRequest(response);
                else
                    return Ok(response);
            }
            else
            {
                return Unauthorized();
            }

        }

        [HttpPost("login")]
        public async Task<ActionResult<ReleaseNoteUserInfo>> Login(ReleaseNoteUserInfo userInfo)
        {
            try
            {
                var user = await _repository.CheckReleaseNoteUserAsync(userInfo);

                if (user is null)
                {
                    //ModelState.AddModelError("", "Invalid username or password.");
                    //return BadRequest(ModelState);
                    return Unauthorized();
                }

                // Create a token and return it in the response
                var token = GenerateTokenAndAddCookie(userInfo);
                return Ok(new { Token = token });
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [Route("addblacklisttoken")]
        [HttpPost]
        public async Task<ActionResult> AddBlackListTokenAsync(ReleaseNoteBlackListedToken releaseNoteBlackListedToken)
        {
            HttpContext.Response.Cookies.Delete("tokenCookie");
            var response = await _repository.AddBlackListTokenAsync(releaseNoteBlackListedToken);
            if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                return BadRequest(response);
            }
            else
            {
                return Ok(response);
            }

            //return CreatedAtAction(nameof(GetReleaseNoteByIdAsync), new { id = item.Id }, item);
            //return NoContent(); 

        }

        private string GenerateTokenAndAddCookie(ReleaseNoteUserInfo user)
        {
            JwtSecurityToken jwtSecurityToken;
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes("VersionGenerator@Broadstone@Jun23");
            var localTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.Local);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Name, user.UserEmail),
                    // ... add more claims as needed
                }),
                Expires = DateTime.UtcNow.AddHours(1),
                //IssuedAt = new DateTime(localTime.Ticks, DateTimeKind.Utc),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            jwtSecurityToken = (JwtSecurityToken)token;
            CookieOptions options = new()
            {
                Expires = DateTime.Now.AddHours(1),

                //!this will enable the cookie to be shared within Web API project only running on (https://localhost:7119)
                SameSite = SameSiteMode.Strict,

                Secure = true

            };
            HttpContext.Response.Cookies.Append("tokenCookie", jwtSecurityToken.RawData, options);

            return tokenHandler.WriteToken(token);
        }

        private async Task<bool> ValidateToken()
        {
            //bool boolvar=false;
            try
            {
                string authorizationHeader = Request.Headers["Authorization"];
                if (string.IsNullOrEmpty(authorizationHeader))
                {
                    // No token is sent from the client
                    return false;
                }
                else
                {
                    var token = Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

                    if (HttpContext.Request.Cookies.Count > 1)
                    {
                        if (token != HttpContext.Request.Cookies["tokenCookie"].ToString())
                        {
                            return false;
                        }
                    }

                    var blackListToken = await _repository.GetBlackListedTokenByIdAsync(token);
                    if (blackListToken.Count == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                return false;
            }

        }



    }
}
