﻿namespace WebApi.Model
{
    public class ReleaseNoteThreshold
    {
        public byte ID { get; set; }
        public string ApplicationName { get; set; }
        public byte FeatureUserStoryThreshold { get; set; }
        public byte BugThreshold { get; set; }
        public string LastVersion { get; set; }


    }
}
