﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Model
{
    public class ReleaseNoteThreshold
    {
        public int Id { get; set; }
        public string ApplicationName { get; set; }
        public byte FeatureUserStoryThreshold { get; set; }
        public byte BugThreshold { get; set; }
        public string LastVersion { get; set; }
        public string ADOProject { get; set; }

        [Required(ErrorMessage = "Application description is required")]
        public string ApplicationDescription { get; set; }


    }
}
