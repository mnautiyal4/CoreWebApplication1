﻿using System.ComponentModel.DataAnnotations;
namespace WebApi.Model
{
    public class ReleaseNote
    {
        public int Id { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string ApplicationName { get; set; }
        public string WorkItemType { get; set; }

        public int AdoID { get; set; }

        //[Required(ErrorMessage = "ADO link is required")]
        public string AdoLink { get; set; }

        public int ChangeRequestID { get; set; }

        //[Required(ErrorMessage = "Change request link is required")]
        public string ChangeRequestLink { get; set; }

        [Required(ErrorMessage = "Release item title is required")]
        public string ReleaseItemTitle { get; set; }

        [Required(ErrorMessage = "Release item description is required")]
        public string ReleaseItemDescription { get; set; }
        public string ReleaseVersion { get; set; }
        public bool AllowUpdate { get; set; }
        public bool AllowDelete { get; set; }
        public DateTime ModifiedOn { get; set; }
        public string ModifiedBy { get; set; }
        public string UserIPAddress { get; set; }

    }
}
