﻿namespace WebApi.Model
{
    public class ReleaseNoteBlackListedToken
    {
        public int Id { get; set; }
        public string Token { get; set; }
        public string TokenBlackListDateTime { get; set; }
    }
}
