﻿using System.ComponentModel.DataAnnotations;
namespace WebApi.Model
{
    public class StoredProcResult
    {
        [Key]
        public int Col1 { get; set; }
        public int Col2 { get; set; }
        public string Col3 { get; set; }
        public string Col4 { get; set; }
        //public DateTime Col5 { get; set; }
        //public DateTime Col6 { get; set; }
    }
}
