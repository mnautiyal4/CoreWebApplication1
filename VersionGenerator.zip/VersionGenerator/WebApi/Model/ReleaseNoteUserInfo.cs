﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Model
{
    public class ReleaseNoteUserInfo
    {
        public short Id { get; set; }
        [Required(ErrorMessage = "Email is required")]
        public string UserEmail { get; set; }
        [Required(ErrorMessage = "Password is required")]
        public string UserPassword { get; set; }
        public string UserRole { get; set; }
    }
}
