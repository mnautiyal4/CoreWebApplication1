﻿namespace WebApi.Model
{
    public class ReleaseNoteDataTransferObject
    {
        public ReleaseNote NewReloeaseNote { get; set; }
        public List<ReleaseNote> ReleaseNoteList { get; set; }
    }
}
