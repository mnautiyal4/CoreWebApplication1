﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Model
{
    public class StoredProcInput
    {
        [Key]
        [Required(ErrorMessage = "This input is required")]
        public int Col1 { get; set; }
        //[Required(ErrorMessage = "This input is required")]
        public int Col2 { get; set; }
        //[Required(ErrorMessage = "This input is required")]
        public int Col3 { get; set; }
        //[Required(ErrorMessage = "This input is required")]
        public int Col4 { get; set; }
        public string Col5 { get; set; }
        public string Col6 { get; set; }
        public string Col7 { get; set; }
        public string Col8 { get; set; }

        public DateTime Col9 { get; set; }
    }
}
