using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using WebApi.Data;

var builder = WebApplication.CreateBuilder(args);

//! Add services to the container.

builder.Services.AddDbContext<ReleaseNoteDbContext>(options =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<ReleaseNoteRepository>();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddJwtBearer(options =>
        {
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateIssuerSigningKey = true,
                ValidIssuer = builder.Configuration.GetConnectionString("Issuer"),
                ValidAudience = builder.Configuration.GetConnectionString("Audience"),
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("VersionGenerator@Broadstone@Jun23"))
            };
        });
//
//builder.Services.AddAuthorization(options =>
//{
//    options.AddPolicy("ValidToken", policy =>
//    {
//        policy.RequireAuthenticatedUser();
//        policy.Requirements.Add(new ValidTokenAuthorizationRequirement());
//    });
//});

//builder.Services.AddSingleton<IAuthorizationHandler, ValidTokenAuthorizationHandler>();
//


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
