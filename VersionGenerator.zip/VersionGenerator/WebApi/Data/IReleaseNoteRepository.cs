﻿using WebApi.Model;

namespace WebApi.Data
{
    public interface IReleaseNoteRepository
    {
        Task<List<ReleaseNote>> GetAllReleaseNotesAsync();
        Task<ReleaseNote> GetReleaseNoteByIdAsync(int id);
        Task<HttpResponseMessage> AddReleaseNoteAsync(ReleaseNoteDataTransferObject releaseNoteDataTransferObject);
        Task UpdateReleaseNoteAsync(ReleaseNote ReleaseNoteItem);
        Task DeleteReleaseNoteAsync(int id);
        Task<List<StoredProcResult>> GetResultByProcedureAsync(string AppName, byte Epic, byte Feature, byte Userstory, byte Bug);
        Task<List<StoredProcInput>> GetResultByProcedureInputAsync();
        Task<List<ReleaseNote>> GetReleaseNoteDetailsAsync(string RelDate, string AppaName);
        Task<List<ReleaseNote>> GetLastReleaseNoteListAsync(string AppName, string RelDate);
        Task<HttpResponseMessage> AddReleaseNoteUserAsync(ReleaseNoteUserInfo UserInfo);
        Task<ReleaseNoteUserInfo> CheckReleaseNoteUserAsync(ReleaseNoteUserInfo userInfo);
        Task<List<ReleaseNoteBlackListedToken>> GetBlackListedTokenByIdAsync(string token);
        Task<HttpResponseMessage> AddBlackListTokenAsync(ReleaseNoteBlackListedToken releaseNoteBlackListedToken);
        Task<ReleaseNoteThreshold> GetApplicationListByIdAsync(int id);
        Task UpdateApplicationDetailAsync(ReleaseNoteThreshold item);
        Task<List<StoredProcInput>> GetLatestReleaseAsync();
    }
}
