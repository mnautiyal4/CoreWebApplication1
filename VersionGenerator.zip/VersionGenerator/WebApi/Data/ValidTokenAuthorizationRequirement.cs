﻿using Microsoft.AspNetCore.Authorization;



namespace WebApi.Data
{
    public class ValidTokenAuthorizationRequirement : IAuthorizationRequirement { }

    public class ValidTokenAuthorizationHandler : AuthorizationHandler<ValidTokenAuthorizationRequirement>
    {
        //private readonly IMemoryCache _cache;
        //private StoredProcResult _procResult = new StoredProcResult();
        private readonly ReleaseNoteRepository _repository;

        //public ValidTokenAuthorizationHandler(IMemoryCache cache)
        //{
        //    _cache = cache;
        //}

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ValidTokenAuthorizationRequirement requirement)
        {
            //if (context.User.Identity.IsAuthenticated)
            //{
            // Check if the token is in the blacklist or revocation list
            string token = GetTokenFromContext(context); // Extract the token from the request context
            if (IsTokenBlacklisted(token))
            {
                context.Fail(); // Token is blacklisted, authorization fails
            }
            else
            {
                context.Succeed(requirement); // Token is valid and not blacklisted
            }
            //}
            //else
            //{
            //    context.Fail(); // User is not authenticated, authorization fails
            //}

            return Task.CompletedTask;
        }

        private string GetTokenFromContext(AuthorizationHandlerContext context)
        {
            // Extract the token from the request context
            // Get the current HttpContext from the authorization context
            HttpContext httpContext = context.Resource as HttpContext;

            // Extract the token from the Authorization header
            string authorizationHeader = httpContext.Request.Headers["Authorization"];
            if (!string.IsNullOrEmpty(authorizationHeader) && authorizationHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                // Remove the "Bearer " prefix to get the token value
                string token = authorizationHeader.Substring("Bearer ".Length).Trim();
                return token;
            }

            // Token not found or in an invalid format
            return null;
        }

        private bool IsTokenBlacklisted(string token)
        {
            // Check if the token is present in the blacklist or revocation list
            var blackListToken = _repository.GetBlackListedTokenByIdAsync(token);
            if (blackListToken != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
