﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using System.Net;
using WebApi.Model;



namespace WebApi.Data
{
    public class ReleaseNoteRepository : IReleaseNoteRepository
    {
        private readonly ReleaseNoteDbContext _dbContext;

        public ReleaseNoteRepository(ReleaseNoteDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<ReleaseNote>> GetAllReleaseNotesAsync()
        {
            return await _dbContext.ReleaseNote.ToListAsync();
        }

        public async Task<ReleaseNote> GetReleaseNoteByIdAsync(int id)
        {
            return await _dbContext.ReleaseNote.FindAsync(id);
        }

        public async Task<HttpResponseMessage> AddReleaseNoteAsync(ReleaseNoteDataTransferObject releaseNoteDataTransferObject)
        {
            byte totepic = 0, totfeature = 0, totuserstory = 0, totbug = 0;

            if (releaseNoteDataTransferObject.NewReloeaseNote.WorkItemType == "Epic")
                totepic = 1;
            else if (releaseNoteDataTransferObject.NewReloeaseNote.WorkItemType == "Feature")
                totfeature = 1;
            else if (releaseNoteDataTransferObject.NewReloeaseNote.WorkItemType == "User Story")
                totuserstory = 1;
            else totbug = 1;

            //! Disable edit and delete button for last records for supplied app name
            List<StoredProcResult> result = GetResultByProcedureAsync(releaseNoteDataTransferObject.NewReloeaseNote.ApplicationName, totepic, totfeature, totuserstory, totbug).Result;
            foreach (StoredProcResult resultItem in result)
            {
                if (resultItem != null)
                {
                    releaseNoteDataTransferObject.NewReloeaseNote.ReleaseVersion = resultItem.Col3;
                    break;
                }
            }
            /*! There are two database transactions, one to add new release note and the other one to update allowupdate and allowdelete
                for all immediate previous records for supplied app name */
            using (var transaction = await _dbContext.Database.BeginTransactionAsync())
            {
                try
                {
                    //! Disable edit and delete button for all immediate previous records for supplied app name
                    foreach (var item in releaseNoteDataTransferObject.ReleaseNoteList)
                    {
                        item.AllowUpdate = false;
                        item.AllowDelete = false;
                        _dbContext.Update(item);
                    }
                    _dbContext.ReleaseNote.Add(releaseNoteDataTransferObject.NewReloeaseNote);
                    await _dbContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    return new HttpResponseMessage(HttpStatusCode.Created);
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    return new HttpResponseMessage(HttpStatusCode.BadRequest);
                }
            }


        }

        public async Task UpdateReleaseNoteAsync(ReleaseNote item)
        {
            _dbContext.Entry(item).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }
        
        public async Task DeleteReleaseNoteAsync(int id)
        {
            var item = await _dbContext.ReleaseNote.FindAsync(id);
            if (item != null)
            {
                _dbContext.ReleaseNote.Remove(item);
                await _dbContext.SaveChangesAsync();
            }
        }

        public async Task<List<StoredProcResult>> GetResultByProcedureAsync(string AppName, byte Epic, byte Feature, byte UserStory, byte Bug)
        {

            return await _dbContext.StoredProcResult.FromSqlRaw("EXEC proc_GetVersion @appname, @totepic, @totfeature, @totuserstory, @totbug",
                new SqlParameter("@appname", AppName),
                new SqlParameter("@totepic", Epic),
                new SqlParameter("@totfeature", Feature),
                new SqlParameter("@totuserstory", UserStory),
                new SqlParameter("@totbug", Bug)
                ).ToListAsync();
        }


        public async Task<List<StoredProcInput>> GetResultByProcedureInputAsync()
        {
            return await _dbContext.StoredProcInput.FromSqlRaw("EXEC proc_GetStoredProcResult").ToListAsync();
        }

        public async Task UpdateEditDeleteStatusAsync()
        {
            await _dbContext.StoredProcInput.FromSqlRaw("EXEC proc_GetStoredProcResult").ToListAsync();
        }

        public async Task<List<ReleaseNote>> GetReleaseNoteDetailsAsync(string RelDate, string AppName)
        {
            string format = "yyyy-MM-dd";
            DateTime rDate = DateTime.ParseExact(RelDate, format, CultureInfo.InvariantCulture);

            return await _dbContext.ReleaseNote.Where(a => a.ReleaseDate == rDate && a.ApplicationName == AppName).ToListAsync();
        }

        public async Task<List<ReleaseNoteThreshold>> GetApplicationListAsync()
        {
            return await _dbContext.ReleaseNoteThreshold.ToListAsync();
        }
        
        public async Task<ReleaseNoteThreshold> GetApplicationListByIdAsync(int id)
        {
            return await _dbContext.ReleaseNoteThreshold.FindAsync(id);
        }

        public async Task UpdateApplicationDetailAsync(ReleaseNoteThreshold item)
        {
            _dbContext.Entry(item).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }
        

        public async Task<List<ReleaseNote>> GetLastReleaseNoteListAsync(string AppName, string RelDate)
        {
            return await _dbContext.ReleaseNote.FromSqlRaw("EXEC proc_GetPreviousReleaseNoteByAppName @appname, @reldate", new SqlParameter("@appname", AppName),
                new SqlParameter("@reldate", RelDate)).ToListAsync();
        }

        public async Task<HttpResponseMessage> AddReleaseNoteUserAsync(ReleaseNoteUserInfo userInfo)
        {
            //! Check if the username or email already exists
            if (await _dbContext.ReleaseNoteUserInfo.AnyAsync(u => u.UserEmail == userInfo.UserEmail))
            {
                return new HttpResponseMessage(HttpStatusCode.Conflict);
            }
            else
            {
                // Hash the password and save the user to the database
                userInfo.UserPassword = BCrypt.Net.BCrypt.HashPassword(userInfo.UserPassword);
                _dbContext.ReleaseNoteUserInfo.Add(userInfo);
                var response = await _dbContext.SaveChangesAsync();
                return new HttpResponseMessage(HttpStatusCode.Created);

            }

        }
        public async Task<ReleaseNoteUserInfo> CheckReleaseNoteUserAsync(ReleaseNoteUserInfo userInfo)
        {
            try
            {
                var user = await _dbContext.ReleaseNoteUserInfo.FirstOrDefaultAsync(u => u.UserEmail == userInfo.UserEmail);
                if (user == null || !BCrypt.Net.BCrypt.Verify(userInfo.UserPassword, user.UserPassword))
                {
                    return null;
                }
                else
                {
                    return user;
                }

            }
            catch (Exception ex)
            {
                return null;

            }
        }
        public async Task<List<ReleaseNoteBlackListedToken>> GetBlackListedTokenByIdAsync(string token)
        {

            //await Task.Delay(10000);
            //var a = _dbContext.ReleaseNoteBlackListedToken.FromSqlRaw("EXEC proc_GetBlackListToken @token",
            //    new SqlParameter("@token", token)
            //    ).ToListAsync();

            // a = a;
            //return Task.FromResult<ReleaseNoteBlackListedToken>(a);
            return await _dbContext.ReleaseNoteBlackListedToken.FromSqlRaw("EXEC proc_GetBlackListToken @token",
                new SqlParameter("@token", token)
                ).ToListAsync();
        }

        public async Task<HttpResponseMessage> AddBlackListTokenAsync(ReleaseNoteBlackListedToken releaseNoteBlackListedToken)
        {
            try
            {
                _dbContext.ReleaseNoteBlackListedToken.Add(releaseNoteBlackListedToken);
                await _dbContext.SaveChangesAsync();
                return new HttpResponseMessage(HttpStatusCode.Created);
            }
            catch (Exception ex)
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }

        }
    }
}
