﻿using Microsoft.EntityFrameworkCore;
using WebApi.Model;

namespace WebApi.Data
{
    public class ReleaseNoteDbContext : DbContext
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public ReleaseNoteDbContext(DbContextOptions<ReleaseNoteDbContext> options) : base(options) { }

        public DbSet<ReleaseNote> ReleaseNote { get; set; }

        public DbSet<StoredProcResult> StoredProcResult { get; set; }

        public DbSet<StoredProcInput> StoredProcInput { get; set; }

        public DbSet<ReleaseNoteThreshold> ReleaseNoteThreshold { get; set; }

        public DbSet<ReleaseNoteUserInfo> ReleaseNoteUserInfo { get; set; }
        public DbSet<ReleaseNoteBlackListedToken> ReleaseNoteBlackListedToken { get; set; }

    }
}
