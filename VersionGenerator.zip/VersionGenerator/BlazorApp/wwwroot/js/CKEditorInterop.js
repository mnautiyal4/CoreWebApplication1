﻿window.CKEditorInterop = (() => {
    const editors = {};

	return {
		init(id, dotNetReference) {
			ClassicEditor
				.create(document.getElementById(id), {

					toolbar: {
						items: [
							'heading',
							'|',
							'bold',
							'italic',
							'link',
							'bulletedList',
							'numberedList',
							'|',
							'indent',
							'outdent',
							'|',
							'blockQuote',
							'insertTable',
							'undo',
							'redo'
						]
					},
					language: 'en',
					image: {
						toolbar: [
							'imageTextAlternative',
							'imageStyle:full',
							'imageStyle:side'
						]
					},
					table: {
						contentToolbar: [
							'tableColumn',
							'tableRow',
							'mergeTableCells'
						]
					},
					licenseKey: '',

				})

				.then(editor => {
					editors[id] = editor;
					editor.model.document.on('change:data', () => {
						let data = editor.getData();

						const el = document.createElement('div');
						el.innerHTML = data;
						if (el.innerText.trim() == '')
							data = null;

						dotNetReference.invokeMethodAsync('EditorDataChanged', data);
					});
				})
				.catch(error => console.error(error));
		},
		destroy(id) {
			editors[id].destroy()
				.then(() => delete editors[id])
				.catch(error => console.log(error));
		},
		hideeditor: function () {

			var editordivOuter = document.querySelectorAll('.ck-editor');
			for (var i = 1, len = editordivOuter.length; i < len; i++) {
				//var editordivinner = editordivOuter[i].querySelector('.ck-editor__editable');
				//editordivinner.innerHTML = '<p>Not required</p>';
				editordivOuter[i].destroy().then(() => delete editordivOuter[i]);
			    editordivOuter[i].style.display = 'none';
			}


		},
		setValue: function (editorID, value) {

			//alert(value);
			
			//var div = document.querySelector('.ck-editor__editable');
			//var txtarea = document.getElementById(editorID);
			//div.innerHTML = value;
			////alert(div.innerHTML);
			//txtarea.innerHTML = value;
			//txtarea.value = value
			//alert(txtarea.innerHTML);
			//alert(txtarea.value);
			
			
		}
	};

})();