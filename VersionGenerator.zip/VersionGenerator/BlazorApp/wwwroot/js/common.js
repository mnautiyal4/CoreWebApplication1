﻿window.showConfirmationDialog = function (message) {
    return new Promise(function (resolve) {
        var result = confirm(message);
        resolve(result);
    });
};

window.clearRichTextEditor = function (editorID) {
    var editor = document.getElementById(editorID);
    if (editor) {
        //editor.innerHTML = "";
        editor.value = '';
    }
};
window.setCookie = function (tokenCookieName, tokenCookieValue, userCookieName, userCookieValue, expirationDays) {
        var expires = "";
        if (expirationDays) {
            var date = new Date();
            date.setTime(date.getTime() + (expirationDays * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
    document.cookie = tokenCookieName + "=" + tokenCookieValue + expires + "; path=/";
    document.cookie = userCookieName + "=" + userCookieValue + expires + "; path=/";
};
window.deleteCookie = function (tokenCookieName, userCookieName) {
    var expires = "; expires=Thu, 01 Jan 1901 00:00:00";
    document.cookie = tokenCookieName + expires + "; path=/";
    document.cookie = userCookieName + expires + "; path=/";
};
window.getCookie = function (cookieName) {
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i].trim();
        if (cookie.startsWith(cookieName + '=')) {
            return cookie.substring(cookieName.length + 1);
        }
    }
    return null;
};

   
