﻿namespace BlazorApp
{
    public interface IUserConnectionTracker
    {
        void AddConnection(string connectionId, string userId);
        void RemoveConnection(string connectionId);
    }

}
