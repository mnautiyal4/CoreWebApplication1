﻿using Microsoft.AspNetCore.SignalR;

namespace BlazorApp
{

    // Custom SignalR Hub
    public class MyHub : Hub
    {
        private readonly IUserConnectionTracker _userConnectionTracker;

        public MyHub(IUserConnectionTracker userConnectionTracker)
        {
            _userConnectionTracker = userConnectionTracker;
        }

        public override async Task OnConnectedAsync()
        {
            //await _userConnectionTracker.AddConnection(Context.ConnectionId, Context.User.Identity.Name);
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            //await _userConnectionTracker.RemoveConnection(Context.ConnectionId);
            await base.OnDisconnectedAsync(exception);
        }
        public async Task SendMessage(string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", message);
        }
    }
}
