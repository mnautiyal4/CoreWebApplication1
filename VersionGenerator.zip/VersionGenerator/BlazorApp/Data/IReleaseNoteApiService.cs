﻿using WebApi.Model;

namespace BlazorApp.Data
{
    public interface IReleaseNoteApiService
    {
        Task<List<ReleaseNote>> GetAllReleaseNotesAsync(string token);
        Task<ReleaseNote> GetReleaseNoteByIdAsync(int Id, string token);
        //Task<ReleaseNote> AddReleaseNoteAsync(ReleaseNoteDataTransferObject releaseNoteDataTransferObject);
        Task<HttpResponseMessage> AddReleaseNoteAsync(ReleaseNoteDataTransferObject releaseNoteDataTransferObject, string token);
        Task UpdateReleaseNoteAsync(int id, ReleaseNote item, string token);
        Task<List<StoredProcResult>> GetResultByProcedureAsync(string AppName, byte Epic, byte Feature, byte UserStory, byte Bug, string token);
        Task<List<StoredProcInput>> GetStoredProcInputAsync();
        Task<List<ReleaseNote>> GetReleaseNoteDetailsAsync(string RelDate, string AppName);
        Task<List<ReleaseNoteThreshold>> GetApplicationListAsync(string token);
        Task<ReleaseNoteThreshold> GetApplicationListByIdAsync(int Id, string token);
        Task<List<ReleaseNote>> GetLastReleaseNoteListAsync(string AppName, string RelDate, string token);
        Task DeleteReleaseNoteAsync(int Id, string token);
        Task<HttpResponseMessage> AddReleaseNoteUserAsync(ReleaseNoteUserInfo UserInfo, string token);
        Task<string> AuthenticateUserAsync(ReleaseNoteUserInfo UserInfo);
        Task<HttpResponseMessage> AddBlackListTokenAsync(ReleaseNoteBlackListedToken releaseNoteBlackListedToken);
        Task UpdateApplicationDetailAsync(int id, ReleaseNoteThreshold item, string token);
    }
}
