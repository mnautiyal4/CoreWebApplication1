﻿using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server.Circuits;
using System.IdentityModel.Tokens.Jwt;
using System.Numerics;
using System.Security.Claims;

namespace BlazorApp.Data
{
    public class TokenAuthenticationStateProvider : AuthenticationStateProvider
    {
        private string _token;
        private string _userName;

        public void SetToken(string token, string userEmail)
        {
            _token = token;
            _userName = userEmail;
            NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
        }

        public override Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            if (!string.IsNullOrEmpty(_token))
            {
                JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
                JwtSecurityToken jwtToken = tokenHandler.ReadJwtToken(_token);

                //! Check if the token has expired
                DateTime expirationDate = jwtToken.ValidTo;
                if (expirationDate > DateTime.UtcNow)
                {
                    /*! If username is not null, the expression will access the value property of expression and assign its value to the variable username.It is equivalent to username = username.value.
                        If username is null, the assignment will not be performed, and username will remain null. This null - conditional operator (?.) is especially useful when working with nullable types or reference 
                        types where you want to avoid null reference exceptions. It allows you to safely access members(properties, methods, etc.) of an object, even if the object 
                        itself is null.If the object is null, the expression evaluates to null instead of throwing a null reference exception.
                        Please note that the value property must be nullable for the null - conditional operator to be used in this way.If the value property 
                        is not nullable, you may not need the null - conditional operator. */
                    var username = jwtToken.Claims.FirstOrDefault(c => c.Type == "unique_name")?.Value;
                    if(!string.IsNullOrEmpty(username))
                    {
                        if (username == _userName)
                        {
                            var identity = new ClaimsIdentity(jwtToken.Claims, "jwt");
                            var user = new ClaimsPrincipal(identity);
                            return Task.FromResult(new AuthenticationState(user));
                        }
                        else
                        {
                            return Task.FromResult(new AuthenticationState(new ClaimsPrincipal()));
                        }
                    }
                    else
                    {
                        return Task.FromResult(new AuthenticationState(new ClaimsPrincipal()));
                    }
                    
                    //var claims = new[] { new Claim(ClaimTypes.Name, _userName), new Claim("Token", _token) };
                }
                else
                {
                    return Task.FromResult(new AuthenticationState(new ClaimsPrincipal()));
                }
            }
            else
            {
                return Task.FromResult(new AuthenticationState(new ClaimsPrincipal()));
            }
        }
        public string GetToken()
        {
            return _token;
        }
    }
}
