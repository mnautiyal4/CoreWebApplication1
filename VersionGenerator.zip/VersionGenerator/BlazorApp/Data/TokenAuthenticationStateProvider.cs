﻿using Microsoft.AspNetCore.Components.Authorization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace BlazorApp.Data
{
    public class TokenAuthenticationStateProvider : AuthenticationStateProvider
    {
        private string _token;
        private string _userName;

        public void SetToken(string token, string userEmail)
        {
            _token = token;
            _userName = userEmail;
            NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
        }

        public override Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            if (!string.IsNullOrEmpty(_token))
            {
                JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
                JwtSecurityToken jwtToken = tokenHandler.ReadJwtToken(_token);

                // Check if the token has expired
                DateTime expirationDate = jwtToken.ValidTo;
                if (expirationDate > DateTime.UtcNow)
                {

                    var claims = new[] { new Claim(ClaimTypes.Name, _userName), new Claim("Token", _token) };
                    var identity = new ClaimsIdentity(claims, "jwt");
                    var user = new ClaimsPrincipal(identity);
                    return Task.FromResult(new AuthenticationState(user));
                }
                else
                {
                    return Task.FromResult(new AuthenticationState(new ClaimsPrincipal()));
                }
            }
            else
            {
                return Task.FromResult(new AuthenticationState(new ClaimsPrincipal()));
            }
        }
        public string GetToken()
        {
            return _token;
        }
    }
}
