﻿using System.Net;
using System.Net.Http.Headers;
using System.Text.Json;
using WebApi.Model;


namespace BlazorApp.Data
{
    public class ReleaseNoteApiService : IReleaseNoteApiService
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;
        private TokenAuthenticationStateProvider _authStateProvider = new TokenAuthenticationStateProvider();
        private HttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
        private HttpContext _httpContext;




        public ReleaseNoteApiService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _baseUrl = configuration.GetValue<string>("ApiBaseUrl");
        }

        public async Task<List<ReleaseNote>> GetAllReleaseNotesAsync(string token)
        {
            //_httpContext.Request.Cookies["tokenCookie"].ToString()
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _httpClient.GetFromJsonAsync<List<ReleaseNote>>(_baseUrl);

        }

        public async Task<ReleaseNote> GetReleaseNoteByIdAsync(int Id, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _httpClient.GetFromJsonAsync<ReleaseNote>(_baseUrl + Id);
        }
        //public async Task<ReleaseNote> AddReleaseNoteAsync(ReleaseNoteDataTransferObject releaseNoteDataTransferObject)
        public async Task<HttpResponseMessage> AddReleaseNoteAsync(ReleaseNoteDataTransferObject releaseNoteDataTransferObject, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await _httpClient.PostAsJsonAsync(_baseUrl + "add", releaseNoteDataTransferObject);
            if (response.IsSuccessStatusCode)
            {
                return new HttpResponseMessage(HttpStatusCode.Created);
            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
            //return await response.Content.ReadFromJsonAsync<ReleaseNote>();
        }

        public async Task UpdateReleaseNoteAsync(int Id, ReleaseNote item, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            await _httpClient.PutAsJsonAsync(_baseUrl + Id, item);
        }

        public async Task UpdateApplicationDetailAsync(int Id, ReleaseNoteThreshold item, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            await _httpClient.PutAsJsonAsync(_baseUrl + "appdetails/" + Id, item);
        }

        public async Task<List<StoredProcResult>> GetResultByProcedureAsync(string AppName, byte Epic, byte Feature, byte UserStory, byte Bug, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _httpClient.GetFromJsonAsync<List<StoredProcResult>>(_baseUrl + "checkversion/" + AppName + "/" + Epic + "/" + Feature + "/" + UserStory + "/" + Bug);

        }

        public async Task<List<StoredProcInput>> GetStoredProcInputAsync()
        {
            //_httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _httpClient.GetFromJsonAsync<List<StoredProcInput>>(_baseUrl + "viewreleasenotes");

        }
        public async Task<List<ReleaseNote>> GetReleaseNoteDetailsAsync(string RelDate, string AppName)
        {
            //_httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _httpClient.GetFromJsonAsync<List<ReleaseNote>>(_baseUrl + "viewreleasenotedetails/" + RelDate + "/" + AppName);
        }
        public async Task<List<ReleaseNoteThreshold>> GetApplicationListAsync(string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _httpClient.GetFromJsonAsync<List<ReleaseNoteThreshold>>(_baseUrl + "applicationlist");
        }

        public async Task<List<ReleaseNote>> GetLastReleaseNoteListAsync(string AppName, string RelDate, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _httpClient.GetFromJsonAsync<List<ReleaseNote>>(_baseUrl + "getlastrecordsbyappname/" + AppName + "/" + RelDate);
        }

        public async Task<ReleaseNoteThreshold> GetApplicationListByIdAsync(int Id, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await _httpClient.GetFromJsonAsync<ReleaseNoteThreshold>(_baseUrl + "appdetails/" + Id);
        }
        public async Task DeleteReleaseNoteAsync(int Id, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            await _httpClient.DeleteAsync(_baseUrl + Id);
        }
        public async Task<HttpResponseMessage> AddReleaseNoteUserAsync(ReleaseNoteUserInfo UserInfo, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await _httpClient.PostAsJsonAsync(_baseUrl + "register", UserInfo);
            return response;
        }
        public async Task<string> AuthenticateUserAsync(ReleaseNoteUserInfo UserInfo)
        {

            // Make the API call to retrieve protected data
            var response = await _httpClient.PostAsJsonAsync(_baseUrl + "login", UserInfo);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                var result = await response.Content.ReadAsStringAsync();
                JsonDocument responseJson = JsonDocument.Parse(result);

                // Access the 'token' property and extract the JWT token
                string jwtToken = responseJson.RootElement.GetProperty("token").GetString();
                return jwtToken;
            }
            else
            {
                return null;
            }
        }
        public async Task<HttpResponseMessage> AddBlackListTokenAsync(ReleaseNoteBlackListedToken releaseNoteBlackListedToken)
        {
            var response = await _httpClient.PostAsJsonAsync(_baseUrl + "addblacklisttoken", releaseNoteBlackListedToken);
            if (response.IsSuccessStatusCode)
            {
                return new HttpResponseMessage(HttpStatusCode.Created);
            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
            //return await response.Content.ReadFromJsonAsync<ReleaseNote>();
        }

    }
}
