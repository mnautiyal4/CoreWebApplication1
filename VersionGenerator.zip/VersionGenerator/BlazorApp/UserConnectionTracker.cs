﻿namespace BlazorApp
{
    using System.Collections.Concurrent;

    public class UserConnectionTracker : IUserConnectionTracker
    {
        private readonly ConcurrentDictionary<string, string> _connections = new ConcurrentDictionary<string, string>();

        public void AddConnection(string connectionId, string userId)
        {
            _connections.TryAdd(connectionId, userId);
        }

        public void RemoveConnection(string connectionId)
        {
            _connections.TryRemove(connectionId, out _);
            // Perform logout operation for the associated user, e.g., invalidating session or revoking token
        }

    }
}
