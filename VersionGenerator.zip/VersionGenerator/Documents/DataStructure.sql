-- Tables ------------------------------------------
CREATE TABLE [dbo].[ReleaseNoteUserInfo](
	[Id] [smallint] IDENTITY(1,1) NOT NULL,
	[UserEmail] [varchar](50) NOT NULL,
	[UserPassword] [varchar](100) NOT NULL,
	[UserRole] [varchar](50) NOT NULL,
 CONSTRAINT [PK_ReleaseNoteUserInfo] PRIMARY KEY CLUSTERED 
(
	[UserEmail] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
------------------------------

CREATE TABLE [dbo].[ReleaseNoteThreshold](
	[Id] [int] NOT NULL,
	[ApplicationName] [varchar](50) NULL,
	[FeatureUserStoryThreshold] [tinyint] NULL,
	[BugThreshold] [tinyint] NULL,
	[LastVersion] [varchar](15) NULL,
	[ADOProject] [varchar](50) NULL,
	[ApplicationDescription] [varchar](max) NULL,
 CONSTRAINT [PK_ReleaseNoteThreshold] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

--------------------------------

CREATE TABLE [dbo].[ReleaseNoteBlackListedToken](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Token] [varchar](max) NULL,
	[TokenBlackListDateTime] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
--------------------------------------
CREATE TABLE [dbo].[ReleaseNote](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ReleaseDate] [date] NOT NULL,
	[ApplicationName] [varchar](50) NOT NULL,
	[WorkItemType] [varchar](50) NOT NULL,
	[AdoID] [int] NULL,
	[AdoLink] [varchar](2000) NULL,
	[ChangeRequestID] [int] NULL,
	[ChangeRequestLink] [varchar](2000) NULL,
	[ReleaseItemTitle] [varchar](1000) NOT NULL,
	[ReleaseItemDescription] [varchar](max) NOT NULL,
	[ReleaseVersion] [varchar](15) NOT NULL,
	[AllowUpdate] [bit] NULL,
	[AllowDelete] [bit] NULL,
	[ModifiedOn] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
	[UserIPAddress] [varchar](50) NULL,
 CONSTRAINT [PK_tbl_ReleaseNotes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
-------------------------------------------



-- SPs ---------------------------------------------

CREATE PROCEDURE [dbo].[proc_GetLatestVersionList]    

AS    
BEGIN
	SELECT CAST(ROW_NUMBER() OVER(ORDER BY a.ApplicationName) as INT) Col1, 0 Col2, 0 Col3, 0 Col4, a.ApplicationName Col5, ISNULL(b.ReleaseVersion,a.LastVersion) Col6, 'Col7' Col7, 'Col8' Col8,ISNULL(b.ReleaseDate,a.ReleaseDate) Col9 FROM
	(
	SELECT '2023/04/01' ReleaseDate, ApplicationName, LastVersion from ReleaseNoteThreshold
	) a
	LEFT JOIN
	(
	SELECT  ReleaseDate, ApplicationName, ReleaseVersion FROM ReleaseNote where id in (select max(id) from ReleaseNote GROUP BY ApplicationName)
	) b on a.ApplicationName=b.ApplicationName ORDER BY Col5
END   

--------------------------------------------------------------

CREATE PROCEDURE [dbo].[proc_GetVersion]    --'4myPlan', 255,255,255,255  
@AppName VARCHAR(50),      
@TotEpic SMALLINT,      
@TotFeature SMALLINT,      
@TotUserStory SMALLINT,      
@TotBug SMALLINT  
AS      
BEGIN      
 DECLARE @EpicPart SMALLINT, @FeatureOrUserStoryPart SMALLINT, @BugPart SMALLINT    
 DECLARE @FeatureUserStoryThreshold SMALLINT, @BugThreshold SMALLINT   
 DECLARE @RVersion VARCHAR(15)    
  
 SET @RVersion = (SELECT ReleaseVersion FROM ReleaseNote WHERE id IN (SELECT max(id) FROM ReleaseNote WHERE ApplicationName=@AppName))    
  
 -- Handling null if no record found for supplied appname  
 IF @RVersion IS NULL  
 SET @RVersion = (SELECT LastVersion FROM ReleaseNoteThreshold WHERE  ApplicationName=@AppName)
 -- Select threshold value for feature/user story and bug  
 SET @FeatureUserStoryThreshold = (SELECT FeatureUserStoryThreshold FROM ReleaseNoteThreshold WHERE ApplicationName=@AppName)    
 SET @BugThreshold = (SELECT BugThreshold FROM ReleaseNoteThreshold WHERE ApplicationName=@AppName)    
   
 -- Break last version into epic, feature/user story and bug parts  
 SET @EpicPart = CAST(SUBSTRING(@RVersion,1,CHARINDEX('.',@RVersion)-1) AS TINYINT)    
 SET @FeatureOrUserStoryPart = CAST(SUBSTRING(@RVersion,LEN(@EpicPart)+2,CHARINDEX('.',@RVersion,LEN(@EpicPart)+2)-LEN(@EpicPart)-2) AS TINYINT)    
 SET @BugPart = CAST(SUBSTRING(@RVersion,LEN(@EpicPart) + Len(@FeatureOrUserStoryPart)+3,Len(@Rversion)) AS TINYINT)    
   
 SET @EpicPart = @EpicPart + @TotEpic    
 SET @FeatureOrUserStoryPart = @FeatureOrUserStoryPart + @TotFeature + @TotUserStory   
 SET @BugPart = @BugPart + @TotBug    
 
 -- if bug part comes out as more than threshold value then add 1 to feature/user story part and reset bug part to 0  
 IF @BugPart > @BugThreshold   
 BEGIN  
  SET @FeatureOrUserStoryPart = @FeatureOrUserStoryPart + 1   
  SET @BugPart = 0   
 END  
  
 -- if feature/user story part comes out as more than threshold value then add 1 to epic part and reset feature/user story part to 0  
 IF @FeatureOrUserStoryPart > @FeatureUserStoryThreshold  
 BEGIN  
  SET @EpicPart = @EpicPart + 1  
  SET @FeatureOrUserStoryPart = 0   
  SET @BugPart = 0   
 END  
    
 SET @RVersion = CAST(@EpicPart as varchar(3)) + '.' + CAST(@FeatureOrUserStoryPart as varchar(2)) +'.' + CAST(@BugPart as varchar(2))    
 SELECT 0 Col1, 0 Col2, @RVersion Col3, '0' Col4     
END  
--------------------------------------------------

CREATE PROCEDURE [dbo].[proc_GetStoredProcResult]    

AS    
BEGIN    
	SELECT CAST(ROW_NUMBER() OVER(ORDER BY c.ReleaseDate desc,c.ApplicationName) as INT) Col1, ISNULL(EPIC,0)+ISNULL(FEATURE,0)+ISNULL([USER STORY],0) Col2, ISNULL(Bug,0) Col3, 0 Col4, 'Col5' Col5, c.ApplicationName Col6,d.ReleaseVersion Col7, 'Col8' Col8, c.ReleaseDate Col9 FROM
	(
	SELECT * FROM
	(
	SELECT ReleaseDate, ApplicationName, workitemtype, COUNT(WorkItemType) itemcount FROM ReleaseNote GROUP BY ReleaseDate, ApplicationName,WorkItemType
	) a
	PIVOT
	(
	SUM(itemcount) FOR workitemtype in ([Epic],[Feature],[User Story],[Bug])
	) b
	) c INNER JOIN
	(
	SELECT  ReleaseDate, ApplicationName, max(ReleaseVersion) ReleaseVersion FROM ReleaseNote GROUP BY ReleaseDate, ApplicationName
	) d ON c.ApplicationName = d.ApplicationName and c.ReleaseDate = d.ReleaseDate ORDER BY c.ReleaseDate desc,c.ApplicationName
END   
----------------------------------------------------

CREATE PROCEDURE [dbo].[proc_GetPreviousReleaseNoteByAppName]      
@AppName VARCHAR(50),
@RelDate Date
AS      
BEGIN   
	SELECT * FROM ReleaseNote WHERE ReleaseDate in (SELECT ReleaseDate FROM ReleaseNote WHERE id IN (SELECT max(id) FROM ReleaseNote WHERE ApplicationName=@AppName and ReleaseDate!=@RelDate)) and ApplicationName=@AppName   
END      
-----------------------------------------

CREATE PROCEDURE [dbo].[proc_GetBlackListToken]    
@token VARCHAR(MAX)
AS    
BEGIN    
	SELECT * FROM ReleaseNoteBlacklistedToken WHERE token=@token
END    
   